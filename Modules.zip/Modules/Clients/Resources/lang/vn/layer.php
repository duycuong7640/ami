<?php

return [
    'user.success' => 'Thành công',
    'user.error' => 'Thất bại',

    //user
    'user.register.error' => 'Đăng ký không thành công',
    'user.register.success' => 'Đăng ký thành công',
    'user.login.error' => 'Tài khoản không tồn tại',

    //card
    'card.add.error' => 'Thêm giỏ hàng không thành công',
    'user.payment.error' => 'Thanh toán thất bại',
    'user.payment.success' => 'Thanh toán thành công',

    //contact
    'contact.error' => 'Liên hệ không thành công',
    'contact.success' => 'Liên hệ thành công',

    //notify
    'notify.success' => 'Thành công',
    'notify.fail' => 'Thất bại',
    'notify.confirm.delete' => 'Bạn có chắc chắn muốn xóa mục đã chọn không?',
    '' => '',
    '' => '',
    '' => '',
    '' => '',
    '' => '',
    '' => '',
    '' => '',
    '' => '',
    '' => '',
    '' => '',
    '' => '',
    '' => '',
    '' => '',
    '' => '',
    '' => '',
    '' => '',
    '' => '',

];
