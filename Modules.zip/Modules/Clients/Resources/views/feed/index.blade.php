<head>
    @include('feed::links')
</head>﻿