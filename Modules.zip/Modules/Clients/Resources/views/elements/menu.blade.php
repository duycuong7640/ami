<div class="wrap-menu">
    <div class="">
        <div id="smoothmenu1" class="ddsmoothmenu">
            {!! $data_common['category_list']['menu'] !!}
            <br style="clear: left"/>
        </div>
        <a class="animateddrawer" id="ddsmoothmenu-mobiletoggle" href="#">
            <span></span>
        </a>
    </div>
</div>
<script type="text/javascript">
    var link_logo_mobile = '';
    var logo_mobile = '';
</script>