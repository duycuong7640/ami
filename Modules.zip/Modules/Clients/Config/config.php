<?php

return [
    'name' => 'Clients'
];
