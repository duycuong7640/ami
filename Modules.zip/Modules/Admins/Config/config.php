<?php

return [
    'name' => 'Admins'
];
