<!-- plugin css -->
<link rel="stylesheet" href="{{ asset('/static/admin/assets/plugins/%40mdi/font/css/materialdesignicons.min.css') }}"/>
<link rel="stylesheet" href="{{ asset('/static/admin/assets/plugins/perfect-scrollbar/perfect-scrollbar.css') }}"/>
<link rel="stylesheet" href="{{ asset('/static/admin/assets/plugins/simple-line-icons/css/simple-line-icons.css') }}"/>
<link rel="stylesheet" href="{{ asset('/static/admin/assets/plugins/flag-icon-css/css/flag-icon.min.css') }}"/>
<!-- end plugin css -->
<link rel="stylesheet" href="{{ asset('/static/admin/assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker.min.css') }}"/>
<link rel="stylesheet" href="{{ asset('/static/admin/assets/plugins/chartist/chartist.min.css') }}"/>
<link rel="stylesheet" href="{{ asset('/static/admin/assets/plugins/daterangepicker/daterangepicker.css') }}"/>
<link rel="stylesheet" href="{{ asset('/static/admin/assets/plugins/jvectormap/jquery-jvectormap.css') }}"/>
<link rel="stylesheet" href="{{ asset('/static/admin/assets/plugins/icheck/skins/all.css') }}"/>
<link rel="stylesheet" href="{{ asset('/static/admin/assets/plugins/select2/css/select2.min.css') }}"/>
@yield('style')
<!-- common css -->
<link rel="stylesheet" href="{{ asset('/static/admin/css/app.css') }}"/>