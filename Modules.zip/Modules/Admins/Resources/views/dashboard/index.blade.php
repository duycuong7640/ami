@extends('admins::layouts.app')
@section('content')
    <div class="content-wrapper">
        Dashboard
    </div>
@endsection
