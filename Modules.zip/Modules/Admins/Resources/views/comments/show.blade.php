@extends('admins::layouts.app')
@section('content')
    <div class="content-wrapper">
        a
    </div>
@endsection
